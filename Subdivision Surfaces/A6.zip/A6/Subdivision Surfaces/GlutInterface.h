#ifndef GLUT_INTERFACE
#define GLUT_INTERFACE
#include "Object.h"
#include "ObjectSubdivider.h"

void glutInterface(int argc, char** argv, Object & obj);

#endif